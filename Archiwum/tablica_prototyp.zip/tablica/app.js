// Tablica — burza mózgów + krótkie quizy, bez backendu.
// Przeglądarka prowadzącego trzyma stan tablicy; uczestnicy łączą się z nią
// bezpośrednio (WebRTC). Do zestawienia połączenia służą publiczne przekaźniki
// Nostr (biblioteka Trystero) — przez nie idzie tylko zaszyfrowana "zapowiedź",
// treść tablicy płynie wprost między przeglądarkami.
import qrcode from './lib/qrcode.js'

// ---------- konfiguracja ----------
// Zmień na własny, unikalny identyfikator (np. nazwa repo) — oddziela Twoje
// pokoje od innych instancji tej aplikacji.
const APP_ID = 'tablica-zajecia-v1'
// Opcjonalnie serwery TURN, gdyby sieć uczelni blokowała połączenia P2P, np.:
// [{ urls: 'turn:turn.example.org:3478', username: 'u', credential: 'p' }]
const TURN = []

const LOCAL = new URLSearchParams(location.search).has('local') // test w kartach jednej przeglądarki
const COLORS = ['amber', 'green', 'rose', 'teal', 'violet', 'sky'] // złoto, zieleń, pomarańcz… (paleta magtk)
const MAX_TEXT = 500
const MAX_CARDS = 1500
const enc = s => new TextEncoder().encode(s)

// ---------- drobne narzędzia ----------
const $ = (s, r = document) => r.querySelector(s)
function h(tag, props, ...kids) {
  const e = document.createElement(tag)
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue
    if (k === 'class') e.className = v
    else if (k === 'text') e.textContent = v
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v)
    else if (k in e && typeof v !== 'string') e[k] = v
    else e.setAttribute(k, v === true ? '' : v)
  }
  for (const c of kids.flat(Infinity)) {
    if (c == null || c === false) continue
    e.append(c.nodeType ? c : document.createTextNode(String(c)))
  }
  return e
}
const ALPH = 'abcdefghijkmnpqrstuvwxyz23456789'
const uid = (n = 8) => Array.from(crypto.getRandomValues(new Uint8Array(n)), b => ALPH[b % 32]).join('')
const b64u = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const unb64u = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), c => c.charCodeAt(0))
const clean = (s, n = 200) => String(s ?? '').replace(/\u0000/g, '').slice(0, n)
const cleanText = s => clean(s, MAX_TEXT).replace(/\s+$/, '').replace(/^\s+/, '')
async function hid(s) {
  const d = await crypto.subtle.digest('SHA-256', enc('tablica:' + s))
  return b64u(d).slice(0, 12)
}
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d } catch { return d } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} },
  del(k) { try { localStorage.removeItem(k) } catch {} },
}
let toastT
function toast(msg, ms = 2600) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show')
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms)
}
function osoby(n) {
  const d = n % 10, dd = n % 100
  if (n === 1) return '1 osoba'
  if (d >= 2 && d <= 4 && !(dd >= 12 && dd <= 14)) return `${n} osoby`
  return `${n} osób`
}
function slug(s) {
  return (s || 'tablica').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/ł/g, 'l').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'tablica'
}
function stamp() {
  const d = new Date(), p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`
}
function download(name, data, type = 'application/json') {
  const url = typeof data === 'string' && data.startsWith('data:') ? data : URL.createObjectURL(new Blob([data], { type }))
  const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove()
  if (!url.startsWith('data:')) setTimeout(() => URL.revokeObjectURL(url), 5000)
}
async function copy(text) {
  try { await navigator.clipboard.writeText(text); toast('Skopiowano') } catch { toast('Zaznacz i skopiuj ręcznie') }
}
function pickFile(accept = '.json,application/json') {
  return new Promise(res => {
    const i = h('input', { type: 'file', accept, onchange: () => res(i.files[0] || null) })
    i.click()
  })
}

// ---------- tożsamość tej przeglądarki ----------
const me = LS.get('tb.me', null) || { cid: uid(16), name: '' }
LS.set('tb.me', me)
if (LOCAL) { // w trybie testowym każda karta udaje osobną osobę
  try { me.cid = sessionStorage.getItem('tb.cid') || uid(16); sessionStorage.setItem('tb.cid', me.cid) } catch {}
}

// motyw: auto (z systemu) → jasny → ciemny; tryb rzutnika
const THEMES = ['auto', 'light', 'dark']
const THEME_LBL = { auto: '◐ Motyw: auto (system)', light: '☀ Motyw: jasny', dark: '☾ Motyw: ciemny' }
let theme = THEMES.includes(LS.get('tb.theme', 'auto')) ? LS.get('tb.theme', 'auto') : 'auto'
function applyTheme() {
  if (theme === 'auto') delete document.documentElement.dataset.theme
  else document.documentElement.dataset.theme = theme
}
applyTheme()
if (LS.get('tb.big', false)) document.body.classList.add('big')
function themeBtn(short = false) {
  const b = h('button', {
    title: 'Motyw: auto → jasny → ciemny',
    onclick: e => {
      e.stopPropagation()
      theme = THEMES[(THEMES.indexOf(theme) + 1) % THEMES.length]
      LS.set('tb.theme', theme); applyTheme(); upd()
    },
  })
  const upd = () => { b.textContent = short ? { auto: '◐ auto', light: '☀ jasny', dark: '☾ ciemny' }[theme] : THEME_LBL[theme] }
  upd(); return b
}
function toggleBig() { LS.set('tb.big', document.body.classList.toggle('big')) }

// ---------- model ----------
function normQuiz(q = {}) {
  return {
    id: clean(q.id, 40) || uid(),
    title: clean(q.title || 'Quiz', 120),
    questions: (Array.isArray(q.questions) ? q.questions : []).map(qq => {
      const options = (Array.isArray(qq.options) ? qq.options : []).map(o => typeof o === 'string'
        ? { id: uid(), text: clean(o.replace(/^\*\s*/, ''), 200), ok: o.startsWith('*') }
        : { id: clean(o.id, 40) || uid(), text: clean(o.text, 200), ok: !!o.ok })
      return {
        id: clean(qq.id, 40) || uid(), text: clean(qq.text, 500),
        multi: qq.multi ?? options.filter(o => o.ok).length > 1, options,
      }
    }),
    answers: q.answers && typeof q.answers === 'object' && !Array.isArray(q.answers) ? q.answers : {},
  }
}
function normBoard(b = {}, keepLive = false) {
  const sections = (Array.isArray(b.sections) ? b.sections : []).map((s, i) => {
    if (typeof s === 'string') s = { title: s }
    return { id: clean(s.id, 40) || uid(), title: clean(s.title, 120), color: COLORS.includes(s.color) ? s.color : COLORS[i % COLORS.length] }
  })
  const cards = (Array.isArray(b.cards) ? b.cards : []).map(c => ({
    id: clean(c.id, 40) || uid(),
    sec: typeof c.sec === 'number' ? sections[c.sec]?.id : clean(c.sec, 40),
    text: cleanText(c.text), name: clean(c.name, 40), by: clean(c.by, 40) || 'host',
    ts: Number(c.ts) || Date.now(), votes: Array.isArray(c.votes) ? c.votes.map(String) : [],
  })).filter(c => c.text && sections.some(s => s.id === c.sec))
  const quizzes = (Array.isArray(b.quizzes) ? b.quizzes : []).map(normQuiz)
  const st = b.settings || {}
  let live = null
  if (keepLive && b.live && quizzes.some(q => q.id === b.live.id) && ['open', 'closed', 'shown'].includes(b.live.state)) live = { id: b.live.id, state: b.live.state }
  return {
    v: 1, title: clean(b.title || 'Tablica', 120), sections, cards, quizzes, live,
    settings: {
      showNames: st.showNames !== false, votes: st.votes !== false, locked: !!st.locked,
      sort: ['new', 'old', 'votes'].includes(st.sort) ? st.sort : 'new',
    },
  }
}
function quizResults(q) {
  const out = {}
  for (const qq of q.questions) {
    const r = { _n: 0 }
    for (const o of qq.options) r[o.id] = 0
    for (const a of Object.values(q.answers)) {
      const sel = a?.[qq.id]
      if (!Array.isArray(sel) || !sel.length) continue
      r._n++
      for (const o of sel) if (o in r) r[o]++
    }
    out[qq.id] = r
  }
  return out
}
const newQuestion = () => ({ id: uid(), text: '', multi: false, options: [{ id: uid(), text: '', ok: true }, { id: uid(), text: '', ok: false }] })

// ---------- sieć ----------
async function connect(room, pw) {
  const handlers = {}
  const net = { selfId: '', peers: new Set(), onJoin() {}, onLeave() {}, on(t, f) { handlers[t] = f }, send() {}, leave() {} }
  const fire = (t, d, p) => { try { handlers[t]?.(d, p) } catch (e) { console.error(e) } }
  if (LOCAL) {
    const id = uid(10), bc = new BroadcastChannel('tablica:' + room)
    const join = p => { if (!net.peers.has(p)) { net.peers.add(p); net.onJoin(p) } }
    bc.onmessage = ({ data: m }) => {
      if (!m || m.from === id || (m.to && m.to !== id)) return
      if (m.t === '_hi') { const known = net.peers.has(m.from); join(m.from); if (!m.to && !known) bc.postMessage({ t: '_hi', from: id, to: m.from }); return }
      if (m.t === '_bye') { if (net.peers.delete(m.from)) net.onLeave(m.from); return }
      join(m.from); fire(m.t, m.d, m.from)
    }
    net.selfId = id
    net.send = (t, d, to) => bc.postMessage({ t, d, from: id, to })
    net.leave = () => { bc.postMessage({ t: '_bye', from: id }); bc.close() }
    addEventListener('pagehide', () => bc.postMessage({ t: '_bye', from: id }))
    setTimeout(() => bc.postMessage({ t: '_hi', from: id }), 0)
    return net
  }
  const { joinRoom, selfId } = await import('./lib/trystero.js')
  const cfg = { appId: APP_ID, password: pw, relayConfig: { warnOnRelayFailure: false } }
  if (TURN.length) cfg.turnConfig = TURN
  const r = joinRoom(cfg, room, { onJoinError: e => console.warn('[tablica] join error', e) })
  net.selfId = selfId
  const actions = {}
  for (const t of ['chal', 'proof', 'hello', 'op', 'state']) {
    const a = r.makeAction(t)
    a.onMessage = (d, meta) => fire(t, d, meta?.peerId ?? meta)
    actions[t] = a
  }
  r.onPeerJoin = p => { net.peers.add(p); net.onJoin(p) }
  r.onPeerLeave = p => { net.peers.delete(p); net.onLeave(p) }
  net.send = (t, d, to) => {
    try { const x = actions[t].send(d, to ? { target: to } : undefined); x?.catch?.(e => console.warn(e)) } catch (e) { console.warn(e) }
  }
  net.leave = () => { try { r.leave() } catch {} }
  addEventListener('pagehide', () => net.leave())
  return net
}

// ---------- wspólne renderowanie tablicy ----------
const R = { secs: new Map(), addCol: null, role: '' }

function renderShell(role) {
  R.role = role; R.secs.clear(); R.addCol = null
  document.body.dataset.role = role
  $('#main').replaceChildren(h('div', { id: 'capture' },
    h('div', { id: 'warn' }),
    h('h1', { id: 'btitle' }),
    h('section', { id: 'quiz', hidden: true }),
    h('div', { id: 'board' })))
}

function renderBoard(v, role) {
  const host = role === 'host'
  const t = $('#btitle')
  if (document.activeElement !== t) t.textContent = v.title
  document.title = `${v.title} · tablica`
  const wrap = $('#board')
  const ids = new Set(v.sections.map(s => s.id))
  for (const [id, o] of R.secs) if (!ids.has(id)) { o.root.remove(); R.secs.delete(id) }
  v.sections.forEach((s, i) => {
    let o = R.secs.get(s.id)
    if (!o) { o = makeSection(s.id, role); R.secs.set(s.id, o) }
    if (wrap.children[i] !== o.root) wrap.insertBefore(o.root, wrap.children[i] || null)
    o.root.dataset.color = s.color
    sectionHead(o, s, i, v, role)
    const cards = v.cards.filter(c => c.sec === s.id)
    const srt = v.settings.sort
    cards.sort(srt === 'votes' ? (a, b) => b.votes - a.votes || b.ts - a.ts : srt === 'old' ? (a, b) => a.ts - b.ts : (a, b) => b.ts - a.ts)
    o.list.replaceChildren(...cards.map(c => cardEl(c, v, role)))
    const locked = v.settings.locked && !host
    o.form.hidden = locked
    o.lockNote.hidden = !locked
  })
  // kolumna "+ sekcja" w trybie układu
  if (host && H.editSections) {
    if (!R.addCol) R.addCol = h('button', { class: 'addcol noexport', onclick: addSection, text: '+ dodaj sekcję' })
    wrap.append(R.addCol)
  } else if (R.addCol) { R.addCol.remove() }
  if (!v.sections.length && !(host && H.editSections)) {
    if (!wrap.querySelector('.empty')) wrap.append(h('p', { class: 'empty', text: host ? 'Brak sekcji — włącz „Układ”, aby je dodać.' : 'Tablica nie ma jeszcze sekcji.' }))
  } else wrap.querySelector(':scope > .empty')?.remove()
}

function makeSection(id, role) {
  const o = {}
  o.head = h('div', { class: 'sec-head' })
  o.list = h('div', { class: 'list' })
  o.lockNote = h('p', { class: 'locked-note noexport', text: '🔒 Dodawanie zablokowane', hidden: true })
  o.ta = h('textarea', {
    rows: 2, maxlength: MAX_TEXT, placeholder: 'Dopisz…', 'aria-label': 'Nowa kartka',
    onkeydown: e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit() } },
  })
  const submit = () => {
    const text = cleanText(o.ta.value)
    if (!text) return
    if (doOp({ k: 'add', sec: id, text }, role) !== false) o.ta.value = ''
    o.ta.focus()
  }
  o.form = h('div', { class: 'addf noexport' }, o.ta,
    h('div', { class: 'row' }, h('small', { text: 'Enter = dodaj · Shift+Enter = nowa linia' }), h('button', { class: 'pri', onclick: submit, text: 'Dodaj' })))
  o.root = h('section', { class: 'sec' }, o.head, o.form, o.lockNote, o.list)
  return o
}

function sectionHead(o, s, i, v, role) {
  if (o.head.contains(document.activeElement)) return
  const n = v.cards.filter(c => c.sec === s.id).length
  if (role === 'host' && H.editSections) {
    const bs = () => H.board.sections.find(x => x.id === s.id)
    o.head.replaceChildren(
      h('button', { class: 'swatch noexport', title: 'Zmień kolor', onclick: () => { const x = bs(); x.color = COLORS[(COLORS.indexOf(x.color) + 1) % COLORS.length]; hostChanged() } }),
      h('input', { value: s.title, maxlength: 120, placeholder: 'Tytuł sekcji', 'aria-label': 'Tytuł sekcji', oninput: e => { bs().title = clean(e.target.value, 120); hostChanged() } }),
      h('button', { class: 'ic noexport', title: 'W lewo', disabled: i === 0, onclick: () => moveSection(s.id, -1), text: '◀' }),
      h('button', { class: 'ic noexport', title: 'W prawo', disabled: i === v.sections.length - 1, onclick: () => moveSection(s.id, 1), text: '▶' }),
      h('button', { class: 'ic noexport', title: 'Usuń sekcję', onclick: () => delSection(s.id), text: '🗑' }))
  } else {
    o.head.replaceChildren(h('h2', { text: s.title || '(bez tytułu)' }), h('span', { class: 'cnt', text: String(n) }))
  }
}

function cardEl(c, v, role) {
  const admin = role === 'host'
  const canEdit = admin || (c.mine && !v.settings.locked)
  const canDel = admin || c.mine
  return h('article', { class: 'card' + (c.mine && !admin ? ' mine' : '') },
    h('p', { class: 'txt', text: c.text }),
    h('footer', {},
      h('span', { class: 'who', text: c.name || (c.mine && !admin ? 'Ty' : '') }),
      h('span', { class: 'acts noexport' },
        canEdit && h('button', { class: 'ic', title: 'Edytuj', onclick: () => editCard(c, v, role), text: '✎' }),
        canDel && h('button', { class: 'ic', title: 'Usuń', onclick: () => { if (confirm('Usunąć tę kartkę?')) doOp({ k: 'del', id: c.id }, role) }, text: '×' })),
      (v.settings.votes || c.votes > 0) && h('button', {
        class: 'vote' + (c.voted ? ' on' : ''), disabled: !v.settings.votes,
        title: c.voted ? 'Cofnij głos' : 'Zagłosuj', 'aria-pressed': String(!!c.voted),
        onclick: () => doOp({ k: 'vote', id: c.id }, role),
      }, '▲ ', String(c.votes))))
}

function editCard(c, v, role) {
  const ta = h('textarea', { rows: 5, maxlength: MAX_TEXT }, c.text)
  const sel = role === 'host' && h('select', {}, v.sections.map(s => h('option', { value: s.id, selected: s.id === c.sec, text: s.title || '(bez tytułu)' })))
  openDialog('Edytuj kartkę', h('div', { class: 'stack' }, ta, sel && h('label', {}, 'Sekcja', sel)),
    [['Anuluj'], ['Zapisz', () => { const text = cleanText(ta.value); if (!text) return false; doOp({ k: 'edit', id: c.id, text, sec: sel ? sel.value : undefined }, role) }, 'pri']])
  setTimeout(() => ta.focus(), 30)
}

function doOp(o, role) {
  if (role === 'host') { if (applyOp(o, HOST_ACTOR)) hostChanged(); return true }
  return sendOp(o)
}

function openDialog(title, body, buttons = [['Zamknij']]) {
  const d = $('#dlg')
  d.replaceChildren(h('form', { method: 'dialog' },
    h('h3', { text: title }), body,
    h('div', { class: 'dlg-btns' }, buttons.map(([label, fn, cls]) => h('button', {
      value: label, class: cls || '',
      onclick: e => { if (fn && fn(e) === false) e.preventDefault() },
    }, label)))))
  d.onclose = null
  d.showModal()
  return d
}

function resultsEl(questions, res, mine, showOk) {
  return questions.map((qq, i) => {
    const r = res?.[qq.id] || {}, tot = r._n || 0
    return h('div', { class: 'qres' },
      h('p', { class: 'qtext' }, `${i + 1}. ${qq.text}`, qq.multi && h('small', { text: ' · wielokrotny wybór' })),
      qq.options.map(o => {
        const n = r[o.id] || 0, pct = tot ? Math.round(100 * n / tot) : 0
        const ok = showOk && o.ok, my = mine?.[qq.id]?.includes(o.id)
        return h('div', { class: 'bar' + (ok ? ' ok' : '') + (my ? ' my' : '') },
          h('span', { class: 'fill', style: `width:${pct}%` }),
          h('span', { class: 'lbl' }, ok ? '✓ ' : '', o.text || '—', my ? ' ← Ty' : ''),
          h('span', { class: 'num', text: `${n} · ${pct}%` }))
      }))
  })
}

// ---------- eksport ----------
function markdown(m) {
  const L = [`# ${m.title}`, '', `_${new Date().toLocaleString('pl-PL')}_`, '']
  for (const s of m.sections) {
    L.push(`## ${s.title || '(bez tytułu)'}`, '')
    const cs = m.cards.filter(c => c.sec === s.id).sort((a, b) => b.votes - a.votes || a.ts - b.ts)
    if (!cs.length) L.push('_(brak)_')
    for (const c of cs) {
      L.push(`- ${c.text.replace(/\n/g, '  \n  ')}${c.name ? ` — *${c.name}*` : ''}${c.votes ? ` **(+${c.votes})**` : ''}`)
    }
    L.push('')
  }
  for (const q of m.quizzes || []) {
    const res = q.results
    L.push(`## Quiz: ${q.title}`, '')
    q.questions.forEach((qq, i) => {
      const r = res?.[qq.id] || {}, tot = r._n || 0
      L.push(`### ${i + 1}. ${qq.text}${qq.multi ? ' _(wielokrotny wybór)_' : ''}`, '')
      for (const o of qq.options) {
        const n = r[o.id] || 0
        L.push(`- [${o.ok ? 'x' : ' '}] ${o.text}${res ? ` — ${n} (${tot ? Math.round(100 * n / tot) : 0}%)` : ''}`)
      }
      if (res) L.push('', `_Odpowiedzi: ${tot}_`)
      L.push('')
    })
  }
  return L.join('\n')
}
async function exportPNG(title) {
  toast('Przygotowuję obraz…')
  const { toPng } = await import('./lib/html-to-image.js')
  document.body.classList.add('exporting')
  try {
    const node = $('#capture')
    const url = await toPng(node, {
      pixelRatio: 2, backgroundColor: getComputedStyle(document.body).backgroundColor,
      filter: n => !(n.classList && n.classList.contains('noexport')),
    })
    download(`${slug(title)}-${stamp()}.png`, url)
  } catch (e) { console.error(e); toast('Nie udało się zrobić obrazu — użyj „Drukuj / PDF”') } finally { document.body.classList.remove('exporting') }
}
function menu(label, items, cls = '') {
  const d = h('details', { class: 'menu ' + cls })
  const pop = h('div', { class: 'menu-pop' }, items)
  d.append(h('summary', { class: 'btn', text: label }), pop)
  pop.addEventListener('click', e => { if (e.target.closest('button')) d.open = false })
  return d
}
document.addEventListener('click', e => {
  for (const d of document.querySelectorAll('details.menu[open]')) if (!d.contains(e.target)) d.open = false
})

// =====================================================================
// PROWADZĄCY
// =====================================================================
const H = { sess: null, board: null, net: null, priv: null, peers: new Map(), rate: new Map(), editSections: false, showQuiz: false, selQ: null }
const HOST_ACTOR = { ch: 'host', name: '', admin: true }

async function createSession(board) {
  const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify'])
  const pub = b64u(await crypto.subtle.exportKey('raw', kp.publicKey))
  const priv = await crypto.subtle.exportKey('jwk', kp.privateKey)
  LS.set('tb.host', { room: uid(10), pw: uid(16), pub, priv, board: normBoard(board) })
}
async function startHostWith(board) {
  const cur = LS.get('tb.host')
  if (cur && !confirm(`Masz otwartą tablicę „${cur.board?.title}”. Zastąpić ją nową? (Jeśli chcesz ją zachować — najpierw Eksport → JSON.)`)) return
  await createSession(board)
  location.hash = 'host'
}

let saveT
function hostSave() { clearTimeout(saveT); saveT = setTimeout(() => LS.set('tb.host', { ...H.sess, board: H.board }), 300) }
let bcT
function scheduleBroadcast() {
  if (bcT) return
  bcT = setTimeout(() => { bcT = null; for (const [p, pi] of H.peers) H.net.send('state', viewFor(pi.ch), p) }, 120)
}
function hostChanged() { hostSave(); hostRender(); scheduleBroadcast() }

function viewFor(ch) {
  const b = H.board, s = b.settings
  const v = {
    title: b.title, sections: b.sections.map(x => ({ ...x })),
    settings: { showNames: s.showNames, votes: s.votes, locked: s.locked, sort: s.sort },
    cards: b.cards.map(c => ({ id: c.id, sec: c.sec, text: c.text, name: s.showNames ? c.name : '', ts: c.ts, votes: c.votes.length, voted: c.votes.includes(ch), mine: c.by === ch })),
    quiz: null,
  }
  const L = b.live, q = L && b.quizzes.find(x => x.id === L.id)
  if (q) {
    const shown = L.state === 'shown'
    v.quiz = {
      id: q.id, title: q.title, state: L.state,
      questions: q.questions.map(qq => ({ id: qq.id, text: qq.text, multi: qq.multi, options: qq.options.map(o => shown ? { id: o.id, text: o.text, ok: o.ok } : { id: o.id, text: o.text }) })),
      mine: q.answers[ch] || null, results: shown ? quizResults(q) : null,
    }
  }
  return v
}

function rateOk(p) {
  const now = Date.now(), a = (H.rate.get(p) || []).filter(t => now - t < 10000)
  if (a.length >= 30) return false
  a.push(now); H.rate.set(p, a); return true
}

function applyOp(d, actor) {
  const b = H.board
  if (!d || typeof d !== 'object') return false
  const sec = id => b.sections.some(s => s.id === id)
  switch (d.k) {
    case 'add': {
      if (b.settings.locked && !actor.admin) return false
      if (!sec(d.sec) || b.cards.length >= MAX_CARDS) return false
      const text = cleanText(d.text); if (!text) return false
      b.cards.push({ id: uid(), sec: d.sec, text, name: actor.name, by: actor.ch, ts: Date.now(), votes: [] })
      return true
    }
    case 'edit': {
      const c = b.cards.find(c => c.id === d.id && (actor.admin || c.by === actor.ch)); if (!c) return false
      if (b.settings.locked && !actor.admin) return false
      const text = cleanText(d.text); if (!text) return false
      c.text = text
      if (actor.admin && d.sec && sec(d.sec)) c.sec = d.sec
      return true
    }
    case 'del': {
      const i = b.cards.findIndex(c => c.id === d.id && (actor.admin || c.by === actor.ch)); if (i < 0) return false
      b.cards.splice(i, 1); return true
    }
    case 'vote': {
      if (!b.settings.votes) return false
      const c = b.cards.find(c => c.id === d.id); if (!c) return false
      const i = c.votes.indexOf(actor.ch)
      i < 0 ? c.votes.push(actor.ch) : c.votes.splice(i, 1)
      return true
    }
    case 'ans': {
      const L = b.live; if (!L || L.state !== 'open' || d.qz !== L.id) return false
      const q = b.quizzes.find(x => x.id === L.id); if (!q) return false
      const a = {}
      for (const qq of q.questions) {
        let sel = Array.isArray(d.a?.[qq.id]) ? d.a[qq.id].filter(o => qq.options.some(x => x.id === o)) : []
        sel = [...new Set(sel)]; if (!qq.multi) sel = sel.slice(0, 1)
        a[qq.id] = sel
      }
      q.answers[actor.ch] = a
      return true
    }
  }
  return false
}

async function hostMain() {
  const s = LS.get('tb.host')
  H.sess = s
  H.board = normBoard(s.board, true)
  H.showQuiz = !!H.board.live
  try {
    H.priv = await crypto.subtle.importKey('jwk', s.priv, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign'])
  } catch (e) { return fatal('Nie udało się wczytać klucza sesji. Utwórz nową tablicę.') }
  renderShell('host')
  hostTop()
  hostRender()

  // ostrzeżenie o drugiej karcie z tą samą tablicą
  const dup = new BroadcastChannel('tablica-host')
  dup.onmessage = ({ data }) => {
    if (data?.room !== s.room) return
    if (data.t === 'ping') dup.postMessage({ t: 'pong', room: s.room })
    if (data.t === 'pong') $('#warn').replaceChildren(h('p', { class: 'warn noexport', text: 'Ta tablica jest otwarta także w innej karcie. Zostaw jedną — inaczej uczestnicy zobaczą dwie różne wersje.' }))
  }
  dup.postMessage({ t: 'ping', room: s.room })

  const net = H.net = await connect(s.room, s.pw)
  net.onJoin = () => updateStatus()
  net.onLeave = p => { H.peers.delete(p); H.rate.delete(p); updateStatus(); if (H.board.live) renderHostQuiz() }
  net.on('chal', async (d, p) => {
    if (typeof d?.n !== 'string' || d.n.length > 64) return
    const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, H.priv, enc(d.n + '|' + s.room))
    net.send('proof', { n: d.n, s: b64u(sig) }, p)
  })
  net.on('hello', async (d, p) => {
    if (typeof d?.cid !== 'string' || d.cid.length < 8 || d.cid.length > 64) return
    const ch = await hid(d.cid)
    H.peers.set(p, { ch, name: clean(d.name, 40).trim() })
    updateStatus()
    net.send('state', viewFor(ch), p)
    if (H.board.live) renderHostQuiz()
  })
  net.on('op', (d, p) => {
    const pi = H.peers.get(p)
    if (!pi || !rateOk(p)) return
    if (applyOp(d, pi)) hostChanged()
  })
  addEventListener('beforeunload', e => { if (H.peers.size) { e.preventDefault(); e.returnValue = '' } })
}

function shareLink() {
  const s = H.sess
  return `${location.origin}${location.pathname}${LOCAL ? '?local' : ''}#r=${s.room}&k=${s.pw}&h=${s.pub}`
}
function openShare() {
  const url = shareLink()
  const qr = qrcode(0, 'L'); qr.addData(url); qr.make()
  const box = h('div', { class: 'qr' }); box.innerHTML = qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true })
  openDialog('Udostępnij tablicę', h('div', { class: 'share' }, box,
    h('div', { class: 'row' }, h('input', { value: url, readonly: true, 'aria-label': 'Link', onclick: e => e.target.select() }), h('button', { type: 'button', class: 'pri', onclick: () => copy(url), text: 'Kopiuj' })),
    h('p', { class: 'hint', text: 'Klucz sesji jest w części linku po „#” — nie trafia na żaden serwer. Każdy z tym linkiem może dopisywać. Tablica działa, dopóki ta karta jest otwarta.' }),
    h('a', { href: url, target: '_blank', rel: 'noopener', text: 'Otwórz widok uczestnika w nowej karcie ↗' })))
}

function hostTop() {
  const b = () => H.board
  const settingsPop = () => {
    const st = b().settings
    const chk = (key, label) => h('label', {}, h('input', { type: 'checkbox', checked: st[key], onchange: e => { st[key] = e.target.checked; hostChanged(); hostTop() } }), label)
    return [
      chk('showNames', 'Pokazuj podpisy'),
      chk('votes', 'Głosowanie ▲'),
      chk('locked', 'Zablokuj dodawanie'),
      h('label', {}, 'Sortuj', h('select', { onchange: e => { st.sort = e.target.value; hostChanged() } },
        [['new', 'najnowsze'], ['old', 'najstarsze'], ['votes', 'najwięcej głosów']].map(([v, t]) => h('option', { value: v, selected: st.sort === v, text: t })))),
      h('hr'),
      h('button', { onclick: toggleBig, text: 'A+  Tryb rzutnika (większy tekst)' }),
      themeBtn(),
    ]
  }
  $('#top').replaceChildren(...[
    h('a', { class: 'brand', href: '#', title: 'Ekran startowy' }, '[ ', h('b', { text: 'tablica' }), ' ]'),
    h('span', { id: 'status', class: 'pill wait', text: 'łączenie…' }),
    b().settings.locked && h('span', { class: 'pill bad', text: 'zablokowana' }),
    h('span', { class: 'sp' }),
    h('button', { class: 'pri', onclick: openShare, text: 'Udostępnij' }),
    h('button', { class: H.showQuiz ? 'on' : '', onclick: () => { H.showQuiz = !H.showQuiz || !!b().live; hostTop(); renderHostQuiz() }, text: 'Quiz' }),
    h('button', { class: H.editSections ? 'on' : '', title: 'Edycja tytułu i sekcji', onclick: () => { H.editSections = !H.editSections; H.secsReset(); hostTop(); hostRender() }, text: H.editSections ? '✓ Układ' : 'Układ' }),
    menu('Ustawienia', settingsPop()),
    menu('Eksport', [
      h('button', { onclick: () => download(`${slug(b().title)}-${stamp()}.json`, JSON.stringify({ ...b(), live: null, exported: new Date().toISOString() }, null, 2)), text: 'Zapisz całość (.json)' }),
      h('button', { onclick: () => download(`${slug(b().title)}-szablon.json`, JSON.stringify(templateOf(b()), null, 2)), text: 'Zapisz jako szablon (.json, bez wpisów)' }),
      h('button', { onclick: () => download(`${slug(b().title)}-${stamp()}.md`, markdown(hostMd()), 'text/markdown'), text: 'Notatka (.md)' }),
      h('button', { onclick: () => exportPNG(b().title), text: 'Zrzut (.png)' }),
      h('button', { onclick: () => print(), text: 'Drukuj / PDF' }),
    ]),
    menu('Więcej', [
      h('button', { onclick: importIntoSession, text: 'Wczytaj tablicę z pliku .json…' }),
      h('button', { onclick: () => { if (confirm('Usunąć wszystkie kartki (sekcje i quizy zostają)?')) { b().cards = []; hostChanged() } }, text: 'Wyczyść kartki' }),
      h('hr'),
      h('button', { onclick: () => { location.hash = '' }, text: 'Ekran startowy' }),
      h('button', { onclick: endSession, text: 'Zakończ i usuń sesję' }),
    ])].filter(Boolean))
  updateStatus()
}
H.secsReset = () => { for (const o of R.secs.values()) o.head.replaceChildren() }

function updateStatus() {
  const el = $('#status'); if (!el || !H.net) return
  el.className = 'pill ok'
  el.textContent = `${LOCAL ? 'tryb lokalny · ' : ''}${osoby(H.peers.size)}`
  el.title = 'Liczba połączonych uczestników'
}

function hostRender() {
  const v = viewFor('host')
  renderBoard(v, 'host')
  const t = $('#btitle')
  if (H.editSections) {
    if (!t.isContentEditable) {
      t.contentEditable = 'plaintext-only'
      if (t.contentEditable !== 'plaintext-only') t.contentEditable = 'true'
      t.oninput = () => { H.board.title = clean(t.textContent.replace(/\n/g, ' '), 120); hostSave(); scheduleBroadcast() }
      t.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); t.blur() } }
    }
  } else if (t.isContentEditable) { t.removeAttribute('contenteditable'); t.oninput = null }
  renderHostQuiz()
}

function addSection() {
  const b = H.board
  b.sections.push({ id: uid(), title: 'Nowa sekcja', color: COLORS[b.sections.length % COLORS.length] })
  hostChanged()
  const o = R.secs.get(b.sections.at(-1).id); o?.head.querySelector('input')?.select()
}
function moveSection(id, dir) {
  const a = H.board.sections, i = a.findIndex(s => s.id === id), j = i + dir
  if (j < 0 || j >= a.length) return
  ;[a[i], a[j]] = [a[j], a[i]]; H.secsReset(); hostChanged()
}
function delSection(id) {
  const n = H.board.cards.filter(c => c.sec === id).length
  if (n && !confirm(`Sekcja ma ${n} kartek — usunąć razem z nimi?`)) return
  H.board.sections = H.board.sections.filter(s => s.id !== id)
  H.board.cards = H.board.cards.filter(c => c.sec !== id)
  hostChanged()
}
function templateOf(b) {
  return {
    title: b.title, sections: b.sections.map(({ title, color }) => ({ title, color })),
    settings: b.settings,
    quizzes: b.quizzes.map(q => ({ title: q.title, questions: q.questions.map(qq => ({ text: qq.text, multi: qq.multi, options: qq.options.map(o => ({ text: o.text, ok: o.ok })) })) })),
  }
}
function hostMd() {
  const v = viewFor('host'), b = H.board
  return { ...v, quizzes: b.quizzes.filter(q => q.questions.length).map(q => ({ ...q, results: Object.keys(q.answers).length ? quizResults(q) : null })) }
}
async function importIntoSession() {
  const f = await pickFile(); if (!f) return
  try {
    const nb = normBoard(JSON.parse(await f.text()))
    if (!confirm(`Zastąpić bieżącą tablicę zawartością „${nb.title}”? Link dla uczestników się nie zmieni.`)) return
    H.board = nb; H.selQ = null; H.secsReset(); hostChanged(); hostTop(); toast('Wczytano')
  } catch (e) { toast('To nie jest poprawny plik tablicy (.json)') }
}
function endSession() {
  if (!confirm('Zakończyć sesję? Uczestnicy stracą połączenie, a tablica zniknie z tej przeglądarki. Najpierw zapisz eksport, jeśli go potrzebujesz.')) return
  H.net?.leave(); LS.del('tb.host'); H.peers.clear(); location.hash = ''
}

// ----- quiz (prowadzący) -----
function renderHostQuiz() {
  const el = $('#quiz'); if (!el) return
  const b = H.board, L = b.live
  el.hidden = !(H.showQuiz || L)
  if (el.hidden) return
  if (L) H.selQ = L.id
  if (!H.selQ || !b.quizzes.some(q => q.id === H.selQ)) H.selQ = b.quizzes[0]?.id || null
  const q = b.quizzes.find(x => x.id === H.selQ)
  const live = !!(L && q && L.id === q.id)
  const st = L?.state
  const set = state => { b.live = state ? { id: q.id, state } : null; hostChanged() }
  const head = h('div', { class: 'qhead noexport' },
    h('strong', { text: 'Quiz' }),
    b.quizzes.length > 0 && h('select', { disabled: !!L, 'aria-label': 'Wybierz quiz', onchange: e => { H.selQ = e.target.value; renderHostQuiz() } },
      b.quizzes.map(x => h('option', { value: x.id, selected: x.id === H.selQ, text: x.title || '(bez tytułu)' }))),
    h('button', { disabled: !!L, onclick: newQuiz, text: '+ Nowy' }),
    q && h('button', { disabled: live, onclick: () => editQuiz(q), text: 'Edytuj' }),
    q && h('button', { disabled: live, onclick: () => { if (confirm(`Usunąć quiz „${q.title}”?`)) { b.quizzes = b.quizzes.filter(x => x !== q); H.selQ = null; hostChanged() } }, text: 'Usuń' }),
    h('span', { class: 'sp' }),
    q && !L && h('button', { class: 'pri', disabled: !q.questions.length, onclick: () => set('open'), text: '▶ Start' }),
    live && st === 'open' && h('button', { class: 'pri', onclick: () => set('closed'), text: '■ Zamknij odpowiedzi' }),
    live && st === 'closed' && h('button', { onclick: () => set('open'), text: 'Otwórz ponownie' }),
    live && st !== 'shown' && h('button', { class: st === 'closed' ? 'pri' : '', onclick: () => set('shown'), text: 'Pokaż wyniki' }),
    live && st === 'shown' && h('button', { onclick: () => set('closed'), text: 'Ukryj wyniki' }),
    live && h('button', { onclick: () => set(null), text: 'Zakończ quiz' }),
    q && h('button', { disabled: !Object.keys(q.answers).length, onclick: () => { if (confirm('Wyczyścić wszystkie odpowiedzi tego quizu?')) { q.answers = {}; hostChanged() } }, text: 'Wyczyść odpowiedzi' }),
    !L && h('button', { class: 'ic', title: 'Zwiń panel', onclick: () => { H.showQuiz = false; hostTop(); renderHostQuiz() }, text: '×' }))
  if (!q) {
    el.replaceChildren(head, h('p', { class: 'qmeta', text: 'Brak quizów. Kliknij „+ Nowy”, dodaj 1–2 pytania i uruchom.' }))
    return
  }
  const n = Object.keys(q.answers).length
  const label = { open: 'odpowiedzi otwarte', closed: 'odpowiedzi zamknięte (wyniki ukryte)', shown: 'wyniki widoczne dla uczestników' }[st]
  el.replaceChildren(head,
    h('p', { class: 'qtitle', text: q.title }),
    h('p', { class: 'qmeta noexport', text: live ? `● ${label} · odpowiedziało: ${n} z ${H.peers.size}` : `Nieuruchomiony · ${q.questions.length} pyt. · zapisanych odpowiedzi: ${n}` }),
    q.questions.length ? h('div', { class: 'qwrap' }, resultsEl(q.questions, quizResults(q), null, true)) : h('p', { class: 'qmeta', text: 'Quiz nie ma pytań — kliknij „Edytuj”.' }))
}
function newQuiz() {
  const q = { id: uid(), title: `Quiz ${H.board.quizzes.length + 1}`, questions: [newQuestion()], answers: {} }
  H.board.quizzes.push(q); H.selQ = q.id; H.showQuiz = true
  hostChanged(); editQuiz(q)
}
function editQuiz(q) {
  const body = h('div', { class: 'qed' })
  const draw = () => body.replaceChildren(
    h('label', {}, 'Tytuł', h('input', { value: q.title, maxlength: 120, oninput: e => { q.title = clean(e.target.value, 120); hostSave() } })),
    q.questions.map((qq, i) => h('fieldset', {},
      h('legend', { text: `Pytanie ${i + 1}` }),
      h('textarea', { rows: 2, maxlength: 500, placeholder: 'Treść pytania', oninput: e => { qq.text = clean(e.target.value, 500); hostSave() } }, qq.text),
      h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: qq.multi, onchange: e => { qq.multi = e.target.checked; if (!qq.multi) { let seen = false; for (const o of qq.options) { if (o.ok && seen) o.ok = false; if (o.ok) seen = true } } draw() } }), 'wielokrotny wybór (checkboxy)'),
      qq.options.map((o, j) => h('div', { class: 'opt' },
        h('input', { type: qq.multi ? 'checkbox' : 'radio', name: 'ok-' + qq.id, checked: o.ok, title: 'Poprawna odpowiedź', 'aria-label': 'Poprawna', onchange: e => { if (!qq.multi) qq.options.forEach(x => { x.ok = false }); o.ok = e.target.checked; hostSave() } }),
        h('input', { type: 'text', value: o.text, maxlength: 200, placeholder: `Odpowiedź ${j + 1}`, oninput: e => { o.text = clean(e.target.value, 200); hostSave() } }),
        h('button', { type: 'button', class: 'ic', title: 'Usuń odpowiedź', disabled: qq.options.length <= 2, onclick: () => { qq.options.splice(j, 1); draw() }, text: '×' }))),
      h('div', { class: 'row' },
        h('button', { type: 'button', disabled: qq.options.length >= 8, onclick: () => { qq.options.push({ id: uid(), text: '', ok: false }); draw() }, text: '+ odpowiedź' }),
        h('button', { type: 'button', onclick: () => { q.questions.splice(i, 1); draw() }, text: 'Usuń pytanie' })))),
    h('button', { type: 'button', onclick: () => { q.questions.push(newQuestion()); draw() }, text: '+ pytanie' }),
    h('p', { class: 'hint', text: 'Zaznacz poprawne odpowiedzi (kółko/kwadrat po lewej). Zmiany zapisują się na bieżąco.' }))
  draw()
  const d = openDialog('Edycja quizu', body, [['Gotowe', null, 'pri']])
  d.onclose = () => hostChanged()
}

// =====================================================================
// UCZESTNIK
// =====================================================================
const S = { room: '', net: null, host: null, v: null, qsig: '', draft: null, lastName: '' }

async function studentMain(p) {
  const room = S.room = clean(p.get('r'), 40), pw = clean(p.get('k'), 64), pubS = clean(p.get('h'), 200)
  renderShell('student')
  studentTop()
  let pub
  try { pub = await crypto.subtle.importKey('raw', unb64u(pubS), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']) } catch { return fatal('Ten link jest niepełny albo uszkodzony. Poproś prowadzącego o nowy.') }
  const cached = LS.get('tb.last.' + room)
  if (cached) applyState(cached, true)
  else $('#btitle').textContent = 'Łączenie z tablicą…'
  setStatus('wait')
  const net = S.net = await connect(room, pw)
  const pending = new Map()
  const challenge = peer => { const n = uid(16); pending.set(peer, n); net.send('chal', { n }, peer) }
  net.onJoin = peer => { if (!S.host) challenge(peer) }
  net.onLeave = peer => {
    pending.delete(peer)
    if (peer === S.host) { S.host = null; setStatus('lost'); for (const q of net.peers) challenge(q) }
  }
  net.on('proof', async (d, peer) => {
    if (S.host || typeof d?.s !== 'string' || pending.get(peer) !== d.n) return
    pending.delete(peer)
    let ok = false
    try { ok = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, pub, unb64u(d.s), enc(d.n + '|' + room)) } catch {}
    if (!ok || S.host) return
    S.host = peer; setStatus('ok'); sendHello()
  })
  net.on('state', (d, peer) => { if (peer === S.host && d && typeof d === 'object') applyState(d) })
  setTimeout(() => { if (!S.host) setStatus('slow') }, 20000)
}
function sendHello() { if (S.host) S.net.send('hello', { cid: me.cid, name: me.name }, S.host) }
function sendOp(o) {
  if (!S.host) { toast('Brak połączenia z tablicą prowadzącego'); return false }
  S.net.send('op', o, S.host); return true
}
function setStatus(k) {
  const el = $('#status'); if (!el) return
  const m = {
    wait: ['wait', 'łączenie…', 'Szukam tablicy prowadzącego'],
    ok: ['ok', 'połączono', 'Połączono z tablicą prowadzącego'],
    lost: ['bad', 'rozłączono', 'Prowadzący rozłączył się — widzisz ostatnią wersję tablicy. Połączenie wróci samo.'],
    slow: ['wait', 'wciąż szukam…', 'Sprawdź, czy prowadzący ma otwartą tablicę. Sieci uczelniane czasem blokują połączenia P2P — spróbuj przez telefon / hotspot.'],
  }[k]
  el.className = 'pill ' + m[0]; el.textContent = m[1]; el.title = m[2]
  if (k === 'slow' || k === 'lost') toast(m[2], 6000)
}
function studentTop() {
  const nameIn = h('input', {
    class: 'name-in', value: me.name, maxlength: 40, placeholder: 'Podpis (opcjonalnie)', 'aria-label': 'Twój podpis',
    onchange: e => { me.name = clean(e.target.value, 40).trim(); LS.set('tb.me', me); sendHello(); toast(me.name ? `Podpis: ${me.name}` : 'Wpisy bez podpisu') },
  })
  $('#top').replaceChildren(
    h('span', { class: 'brand' }, '[ ', h('b', { text: 'tablica' }), ' ]'),
    h('span', { id: 'status', class: 'pill wait', text: 'łączenie…' }),
    h('span', { class: 'sp' }),
    nameIn,
    menu('⋯', [
      h('button', { onclick: () => S.v && exportPNG(S.v.title), text: 'Zrzut tablicy (.png)' }),
      h('button', { onclick: () => S.v && download(`${slug(S.v.title)}-${stamp()}.md`, markdown({ ...S.v, quizzes: S.v.quiz?.results ? [S.v.quiz] : [] }), 'text/markdown'), text: 'Notatka (.md)' }),
      h('hr'),
      h('button', { onclick: toggleBig, text: 'A+  Większy tekst' }),
      themeBtn(),
    ]))
}
function applyState(v, cached = false) {
  if (!Array.isArray(v.sections) || !Array.isArray(v.cards)) return
  S.v = v
  if (!cached) LS.set('tb.last.' + S.room, v)
  renderBoard(v, 'student')
  renderStudentQuiz(v)
}
function renderStudentQuiz(v) {
  const el = $('#quiz'), q = v.quiz
  if (!q) { el.hidden = true; el.replaceChildren(); S.qsig = ''; return }
  const sig = JSON.stringify([q.id, q.state, q.questions, q.results, q.mine])
  if (sig === S.qsig) return
  S.qsig = sig; el.hidden = false
  if (!S.draft || S.draft.id !== q.id) S.draft = { id: q.id, a: JSON.parse(JSON.stringify(q.mine || {})) }
  if (q.mine && q.state !== 'open') S.draft.a = JSON.parse(JSON.stringify(q.mine))
  const kids = [h('p', { class: 'qtitle', text: q.title })]
  if (q.state === 'open') {
    const status = h('small')
    const same = () => JSON.stringify(normA(S.draft.a, q)) === JSON.stringify(normA(q.mine || {}, q))
    const upd = () => { status.textContent = q.mine ? (same() ? '✓ Wysłano. Możesz zmienić odpowiedź, dopóki quiz jest otwarty.' : 'Masz niewysłane zmiany.') : 'Odpowiedź nie została jeszcze wysłana.' }
    kids.push(h('div', { class: 'qwrap qform' }, q.questions.map((qq, i) => h('div', {},
      h('p', { class: 'qtext' }, `${i + 1}. ${qq.text}`, qq.multi && h('small', { text: ' · zaznacz wszystkie poprawne' })),
      qq.options.map(o => h('label', { class: 'opt' },
        h('input', {
          type: qq.multi ? 'checkbox' : 'radio', name: 'q-' + qq.id, value: o.id,
          checked: (S.draft.a[qq.id] || []).includes(o.id),
          onchange: e => {
            const cur = new Set(qq.multi ? S.draft.a[qq.id] || [] : [])
            e.target.checked ? cur.add(o.id) : cur.delete(o.id)
            S.draft.a[qq.id] = [...cur]; upd()
          },
        }), h('span', { text: o.text })))))))
    kids.push(h('div', { class: 'qsend' }, h('button', { class: 'pri', onclick: () => { if (sendOp({ k: 'ans', qz: q.id, a: S.draft.a })) toast('Wysłano odpowiedź') }, text: q.mine ? 'Wyślij ponownie' : 'Wyślij odpowiedź' }), status))
    upd()
  } else if (q.state === 'closed') {
    kids.push(h('p', { class: 'qmeta', text: q.mine ? '✓ Twoja odpowiedź jest zapisana. Poczekaj na wyniki.' : 'Odpowiedzi są już zamknięte.' }))
  } else {
    kids.push(h('div', { class: 'qwrap' }, resultsEl(q.questions, q.results, q.mine, true)))
  }
  el.replaceChildren(...kids)
}
const normA = (a, q) => q.questions.map(qq => [...(a[qq.id] || [])].sort())

// =====================================================================
// EKRAN STARTOWY
// =====================================================================
async function homeMain() {
  document.body.dataset.role = 'home'
  $('#top').replaceChildren(h('span', { class: 'brand' }, '[ ', h('b', { text: 'tablica' }), ' ]'), h('span', { class: 'sp' }), themeBtn(true))
  const params = new URLSearchParams(location.search)
  const t = params.get('t')
  if (t) {
    params.delete('t')
    history.replaceState(null, '', location.pathname + (params.toString() ? '?' + params : ''))
    if (/^boards\/[\w.-]+\.json$/.test(t)) { await loadTemplate(t); if (location.hash === '#host') return }
  }
  const cur = LS.get('tb.host')
  const title = h('input', { value: 'Burza mózgów', maxlength: 120, 'aria-label': 'Tytuł tablicy' })
  const secs = h('textarea', { rows: 4, 'aria-label': 'Sekcje, każda w osobnej linii' }, 'Co działa dobrze\nCo poprawić\nPomysły')
  const tplBox = h('div', { class: 'tpl' }, h('p', { class: 'hint', text: 'Wczytywanie listy…' }))
  $('#main').replaceChildren(h('div', { class: 'home' },
    h('p', { class: 'kicker' }, h('span', { text: 'Burza mózgów · quizy · zajęcia' }), h('span', { text: '[ magtk ]' })),
    h('h1', { text: 'tablica' }),
    h('p', { class: 'lead' }, h('em', { text: 'Sekcje' }), ' z kartkami, głosowanie i ', h('strong', { text: 'krótkie quizy' }), '.', h('br'),
      'Bez kont i bez serwera — Twoja karta jest „serwerem”, dopóki jest otwarta.'),
    h('div', { class: 'panels' },
      cur && h('div', { class: 'panel cont' },
        h('h2', { text: 'Otwarta tablica' }),
        h('p', { class: 'cont-title', text: cur.board?.title || 'Tablica' }),
        h('p', { class: 'cont-meta', text: `${cur.board?.sections?.length || 0} sekcji · ${cur.board?.cards?.length || 0} kartek · ${cur.board?.quizzes?.length || 0} quizów` }),
        h('div', { style: 'display:flex;gap:.5rem;flex-wrap:wrap' },
          h('button', { class: 'pri', onclick: () => { location.hash = 'host' }, text: 'Wróć do tablicy' }))),
      h('div', { class: 'panel' },
        h('h2', { text: 'Nowa tablica' }),
        h('label', { class: 'stack' }, 'Tytuł', title),
        h('label', { class: 'stack' }, 'Sekcje (jedna na linię)', secs),
        h('button', { class: 'pri', onclick: () => startHostWith({ title: title.value, sections: secs.value.split('\n').map(s => s.trim()).filter(Boolean) }), text: 'Utwórz i otwórz' })),
      h('div', { class: 'panel' },
        h('h2', { text: 'Z szablonu' }), tplBox,
        h('button', { onclick: async () => { const f = await pickFile(); if (!f) return; try { startHostWith(normBoard(JSON.parse(await f.text()))) } catch { toast('To nie jest poprawny plik tablicy (.json)') } }, text: 'Wczytaj plik .json z dysku…' })))))
  try {
    const r = await fetch('boards/index.json', { cache: 'no-cache' })
    if (!r.ok) throw 0
    const list = await r.json()
    tplBox.replaceChildren(...list.map(x => h('button', { onclick: () => loadTemplate('boards/' + x.file) }, x.title, x.desc && h('small', { text: x.desc }))))
    if (!list.length) throw 0
  } catch { tplBox.replaceChildren(h('p', { class: 'hint', text: 'Brak szablonów w repo (boards/index.json).' })) }
}
async function loadTemplate(path) {
  try {
    const r = await fetch(path, { cache: 'no-cache' }); if (!r.ok) throw 0
    await startHostWith(normBoard(await r.json()))
  } catch { toast('Nie udało się wczytać szablonu ' + path) }
}

function fatal(msg) {
  $('#main').replaceChildren(h('div', { class: 'home' }, h('h1', { text: 'Ups' }), h('p', { class: 'lead', text: msg }), h('a', { href: location.pathname, text: '← Ekran startowy' })))
}

// ---------- start ----------
function route() {
  if (!window.isSecureContext || !crypto.subtle) return fatal('Ta strona musi działać przez https (np. GitHub Pages) albo http://localhost.')
  const p = new URLSearchParams(location.hash.slice(1))
  if (p.get('r')) return studentMain(p)
  if (location.hash === '#host' && LS.get('tb.host')) return hostMain()
  return homeMain()
}
addEventListener('hashchange', () => location.reload())
route()
