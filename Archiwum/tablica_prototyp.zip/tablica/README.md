# tablica

Tablica do burzy mózgów i krótkich quizów na zajęcia — w stylu IdeaBoardz, ale **bez backendu**.
Działa na GitHub Pages: prowadzący tworzy sekcje, udostępnia link/QR, uczestnicy dopisują kartki,
głosują i odpowiadają na quiz (jednokrotny / wielokrotny wybór). Na koniec: eksport JSON / Markdown / PNG / PDF.

## Jak to działa bez serwera

- Przeglądarka prowadzącego trzyma stan tablicy (i zapisuje go w `localStorage`).
- Uczestnicy łączą się z nią bezpośrednio przez **WebRTC** (biblioteka [Trystero](https://github.com/dmotz/trystero), MIT).
  Do zestawienia połączenia używane są publiczne przekaźniki **Nostr** — przechodzi przez nie tylko
  zaszyfrowana zapowiedź połączenia, treść tablicy idzie wprost między przeglądarkami.
- **Tablica działa, dopóki karta prowadzącego jest otwarta.** Odświeżenie karty jest bezpieczne:
  stan i link zostają, uczestnicy podłączą się ponownie sami.
- Link ma postać `…/#r=POKÓJ&k=HASŁO&h=KLUCZ`. Część po `#` nie jest wysyłana do żadnego serwera.
  - `k` — hasło szyfrujące sygnalizację (bez niego nie da się dołączyć),
  - `h` — klucz publiczny ECDSA prowadzącego: uczestnik sprawdza podpisem (challenge–response),
    że rozmawia z prawdziwą tablicą, więc student nie podszyje się pod prowadzącego.
- Uprawnienia egzekwuje przeglądarka prowadzącego: uczestnik edytuje/usuwa tylko swoje kartki,
  ma 1 głos na kartkę, limit ~30 operacji / 10 s. Identyfikatory uczestników trafiają do eksportu
  tylko jako skróty SHA-256.

## Wdrożenie na GitHub Pages

1. Skopiuj zawartość folderu do repo (np. `materialy/tablica/` albo osobne repo).
2. W `app.js` zmień `APP_ID` na własny, unikalny ciąg (np. nazwę repo).
3. Settings → Pages → deploy from branch. Gotowe — adres `https://<login>.github.io/<repo>/…/`.

Wszystkie biblioteki i fonty są w `lib/` (bez CDN, bez Google Fonts) — strona nie łączy się z niczym poza przekaźnikami do zestawienia połączeń.

## Wygląd

- Styl jak magtk.github.io: DM Mono + Fraunces, złoto / zieleń / pomarańcz, cienkie linie, kropkowana siatka.
- Motyw **auto** (z ustawień systemu) → **jasny** → **ciemny** — przycisk w „Ustawieniach” (u uczestnika w menu „⋯”), wybór zapamiętywany w przeglądarce.
- Kolory zmienia się w jednym miejscu: zmienne CSS na początku `style.css` (blok jasny i dwa bloki ciemne — dla systemu i dla ręcznego wyboru).

## Test lokalny

Moduły ES nie działają z `file://`, więc:

```bash
python3 -m http.server 8000
# http://localhost:8000/?local
```

`?local` = tryb testowy bez sieci: karty jednej przeglądarki rozmawiają przez `BroadcastChannel`,
każda karta udaje osobną osobę. Otwórz tablicę, „Udostępnij” → „Otwórz widok uczestnika”.

## Na zajęciach

1. Ekran startowy → nowa tablica albo szablon z repo.
2. **Udostępnij** → QR na rzutnik / link na czat (Teams, Moodle).
3. **Układ** — zmiana tytułu, sekcji, kolorów, kolejności.
4. **Quiz** → wybierz/utwórz → ▶ Start → Zamknij odpowiedzi → Pokaż wyniki (z poprawnymi) → Zakończ quiz.
5. **Ustawienia** — podpisy, głosowanie, blokada dodawania, sortowanie, tryb rzutnika (A+).
6. **Eksport** — całość `.json` (do ponownego wczytania), szablon `.json` (bez wpisów), notatka `.md`, `.png`, druk/PDF.

## Szablony w repo

Dodaj plik do `boards/` i wpis do `boards/index.json`:

```json
[{ "file": "moj.json", "title": "Nazwa na liście", "desc": "krótki opis" }]
```

Bezpośredni link do startu z szablonu: `…/?t=boards/moj.json`.

Format tablicy (pola opcjonalne można pominąć):

```json
{
  "title": "Tytuł",
  "sections": ["Prosta sekcja", { "title": "Sekcja z kolorem", "color": "teal" }],
  "settings": { "showNames": true, "votes": true, "locked": false, "sort": "new" },
  "quizzes": [
    {
      "title": "Quiz",
      "questions": [
        { "text": "Jednokrotny wybór", "options": ["A", "*B poprawna", "C"] },
        { "text": "Wielokrotny wybór", "options": ["*A", "*B", "C"] }
      ]
    }
  ]
}
```

- kolory: `amber` (złoty), `green`, `rose` (pomarańczowy), `teal`, `violet`, `sky`,
- `*` na początku odpowiedzi = poprawna; >1 poprawna ⇒ automatycznie wielokrotny wybór
  (można wymusić `"multi": true/false`),
- `sort`: `new` | `old` | `votes`.

Eksport „całość .json” też jest poprawnym szablonem (z kartkami) — można go wczytać i kontynuować.

## Ograniczenia

- Sieci uczelniane/firmowe czasem blokują WebRTC (symetryczny NAT). Objaw: uczestnik długo widzi
  „łączenie…”. Pomaga telefon/hotspot albo własny serwer TURN — wpisz go do `TURN` w `app.js`.
- Połączenia tworzą siatkę (każdy z każdym), więc rozsądnie do ~30–40 osób na tablicę.
- Gdy karta prowadzącego jest zamknięta, nikt nie może dopisywać (uczestnicy widzą ostatnią wersję).
- Kto ma link, może pisać — link to jedyne „uprawnienie”. Na nową grupę twórz nową sesję.

## Licencje

Kod aplikacji: dowolny, Twój. Biblioteki w `lib/` (MIT): Trystero (Dan Motzenbecker),
html-to-image (bubkoo), qrcode-generator (Kazuhiko Arase). Fonty w `lib/fonts/` (SIL OFL 1.1):
DM Mono (Colophon Foundry), Fraunces (Undercase Type) — pliki z pakietów @fontsource.
Pełne teksty licencji: `lib/THIRD_PARTY_LICENSES.txt`, `lib/fonts/OFL-*.txt` — przy kopiowaniu
folderu `lib/` zostaw je razem z plikami.
